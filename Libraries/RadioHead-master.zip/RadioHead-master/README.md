# RadioHead
Git repository for RadioHead wireless networking library.

**This repository is just a clone!**

It's sole use is just to have an easy way to access the sourcecode and revision history.

**Don't create any issues or pull requests as they will be ignored!**

Please submit issues or code changes to the original maintainer of this library through https://groups.google.com/forum/#!forum/radiohead-arduino

----

**Trademarks**
RadioHead is a trademark of AirSpayce Pty Ltd. The RadioHead mark was first used on April 12 2014 for international trade, and is used only in relation to data communications hardware and software and related services. It is not to be confused with any other similar marks covering other goods and services.

**Copyright**
This software is Copyright (C) 2011-2016 Mike McCauley. Use is subject to license conditions. The main licensing options available are GPL V2 or Commercial:

**Open Source Licensing GPL V2**
This is the appropriate option if you want to share the source code of your application with everyone you distribute it to, and you also want to give them the right to share who uses it. If you wish to use this software under Open Source Licensing, you must contribute all your source code to the open source community in accordance with the GPL Version 2 when your application is distributed. See https://www.gnu.org/licenses/gpl-2.0.html

**Commercial Licensing**
This is the appropriate option if you are creating proprietary applications and you are not prepared to distribute and share the source code of your application. Purchase commercial licenses at http://airspayce.binpress.com
